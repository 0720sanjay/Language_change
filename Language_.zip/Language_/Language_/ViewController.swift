//
//  ViewController.swift
//  Language_
//
//  Created by Lalit Arya on 13/04/19.
//  Copyright © 2019 Lalit Arya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var seg: UISegmentedControl!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    

    @IBAction func actionEnglish(_sender: Any){
        
        lblFirstName.text = "FirstNameKey".localizableString(loc: "en")
         lblLastName.text = "LastNmaekey".localizableString(loc: "en")
        
    }

    @IBAction func actionSpanish(_sender: Any){
        lblFirstName.text = "FirstNameKey".localizableString(loc: "es")
        lblLastName.text = "LastNmaekey".localizableString(loc: "es")
        
    }


}


extension String{
    
    func localizableString(loc: String) -> String{
    let path = Bundle.main.path(forResource: loc, ofType: "lproj")
    let bundle = Bundle(path: path!)
    return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
        
    }
    
    
    
}
